package com.example.restuarant_tabsswipe;

import java.util.ArrayList;

import Adapter.GridviewAdapterClass;
import Adapter.TabsPagerAdapter;
import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.Dialog;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

@TargetApi(11)
public class MainActivity extends FragmentActivity implements
		ActionBar.TabListener {

	private ViewPager viewPager;
	private TabsPagerAdapter mAdapter;
	private ActionBar actionBar;

	private String[] Tabs = { "Starter", "Vegeterian", "BBQ", "Fastfood",
			"Desert" };
	
	private GridviewAdapterClass gAdapter;
	private ArrayList<String> listMenu;
	private ArrayList<Integer> listImages;
	
	private GridView gridView;
	public Dialog dialog;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
//		setContentView(R.layout.activity_main);
		setContentView(R.layout.fragment_starter);

		viewPager = (ViewPager) findViewById(R.id.pager);
		actionBar = getActionBar();
		mAdapter = new TabsPagerAdapter(getSupportFragmentManager());

		viewPager.setAdapter(mAdapter);
		actionBar.setHomeButtonEnabled(false);
		actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

		for (String tabs : Tabs) {
			actionBar.addTab(actionBar.newTab().setText(tabs)
					.setTabListener(this));
	
			// FROM HERE, I HAVE ADDED THE CODE TO SHOW THE IMAGES OF THE GRIDVIEW AND SELECT THEM
			
			prepareList();

			gAdapter = new GridviewAdapterClass(this, listMenu, listImages);

			gridView = (GridView) findViewById(R.id.gridViewStarter);
			gridView.setAdapter(gAdapter);

			gridView.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long length) {
					// TODO Auto-generated method stub
					// Toast.makeText(GridViewActivity.this, "" +
					// gAdapter.getItem(position), Toast.LENGTH_SHORT);
					dialog = new Dialog(MainActivity.this);
					dialog.setContentView(R.layout.grid_view_row);
					dialog.setTitle(listMenu.get(position).toString());

					// set dialog text, image, etc
					TextView text = (TextView) dialog.findViewById(R.id.textView1);
//					text.setText("" + gAdapter.getItem(position));
					text.setText(listMenu.get(position).toString());
					ImageView image = (ImageView) dialog.findViewById(R.id.imageView1);
					image.setImageResource(listImages.get(position));

//					Button btnAdd = (Button) dialog.findViewById(R.id.addToOrder);
//					 btnAdd.setOnClickListener(new OnClickListener() {
//					
//					 @Override
//					 public void onClick(View v) {
//					 // TODO Auto-generated method stub
//					 dialog.dismiss();
//					 }
//					 });

					dialog.show();
				}
				

			});
		}
	}
	private void prepareList() {
		// TODO Auto-generated method stub
		listMenu = new ArrayList<String>();

		listMenu.add("Samosa");
		listMenu.add("Fries");
		listMenu.add("Samosa");
		listMenu.add("Fries");
		listMenu.add("Samosa");
		listMenu.add("Fries");

		listImages = new ArrayList<Integer>();

		listImages.add(R.drawable.samosa);
		listImages.add(R.drawable.fries);
		listImages.add(R.drawable.samosa);
		listImages.add(R.drawable.fries);
		listImages.add(R.drawable.samosa);
		listImages.add(R.drawable.fries);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onTabReselected(Tab tab, FragmentTransaction ft) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTabSelected(Tab tab, FragmentTransaction ft) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTabUnselected(Tab tab, FragmentTransaction ft) {
		// TODO Auto-generated method stub

	}

}
