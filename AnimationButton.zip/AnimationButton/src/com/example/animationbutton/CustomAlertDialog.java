package com.example.animationbutton;

import android.app.AlertDialog;
import android.content.Context;

public class CustomAlertDialog extends AlertDialog {

	public CustomAlertDialog(Context context) {
		super(context, R.style.CustomDialogAnimationTheme);
	}
}
