package com.example.animationbutton;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;

public class MainActivity extends Activity {
	private static final int DIALOG_CUSTOM_ANIMATION = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	public void onButtonDialogClick(View view) {
		showDialog(DIALOG_CUSTOM_ANIMATION);
	}
	protected Dialog onCreateDialog(int id) {
    	switch (id) {
		case DIALOG_CUSTOM_ANIMATION:
			CustomAlertDialog dialog = new CustomAlertDialog(this);
			dialog.setTitle("This is the fu... custom animation !");
			dialog.setCancelable(true);
			dialog.setMessage("Feels good to do this :p)");
			return dialog;
		}
    	return super.onCreateDialog(id);
    }
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
