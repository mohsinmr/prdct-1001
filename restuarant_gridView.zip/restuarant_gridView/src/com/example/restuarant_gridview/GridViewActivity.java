package com.example.restuarant_gridview;

import java.util.ArrayList;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

public class GridViewActivity extends Activity {

	private GridviewAdapter gAdapter;
	private ArrayList<String> listMenu;
	private ArrayList<Integer> listImages;

	private GridView gridView;
	public Dialog dialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.grid_view);

		prepareList();

		gAdapter = new GridviewAdapter(this, listMenu, listImages);

		gridView = (GridView) findViewById(R.id.gridView1);
		gridView.setAdapter(gAdapter);

		gridView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long length) {
				// TODO Auto-generated method stub
				// Toast.makeText(GridViewActivity.this, "" +
				// gAdapter.getItem(position), Toast.LENGTH_SHORT);
				dialog = new Dialog(GridViewActivity.this);
				dialog.setContentView(R.layout.custom);
				dialog.setTitle(listMenu.get(position).toString());

				// set dialog text, image, etc
				TextView text = (TextView) dialog.findViewById(R.id.text);
//				text.setText("" + gAdapter.getItem(position));
				text.setText(listMenu.get(position).toString());
				ImageView image = (ImageView) dialog.findViewById(R.id.image);
				image.setImageResource(listImages.get(position));

				Button btnAdd = (Button) dialog.findViewById(R.id.addToOrder);
//				 btnAdd.setOnClickListener(new OnClickListener() {
//				
//				 @Override
//				 public void onClick(View v) {
//				 // TODO Auto-generated method stub
//				 dialog.dismiss();
//				 }
//				 });

				dialog.show();
			}
			

		});
	}

	private void prepareList() {
		// TODO Auto-generated method stub
		listMenu = new ArrayList<String>();

		listMenu.add("Samosa");
		listMenu.add("Fries");
		listMenu.add("Samosa");
		listMenu.add("Fries");
		listMenu.add("Samosa");
		listMenu.add("Fries");

		listImages = new ArrayList<Integer>();

		listImages.add(R.drawable.samosa);
		listImages.add(R.drawable.fries);
		listImages.add(R.drawable.samosa);
		listImages.add(R.drawable.fries);
		listImages.add(R.drawable.samosa);
		listImages.add(R.drawable.fries);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.grid_view, menu);
		return true;
	}

}
