/** Automatically generated file. DO NOT MODIFY */
package com.example.restuarant_gridview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}